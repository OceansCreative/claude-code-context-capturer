function a(t,n=new Date){var e;const o=s(n),i=((e=t.title)==null?void 0:e.trim())||t.url;return`## ${o} — ${i}`}function c(t,n){return`

${t}

${n.trim()}
`}function s(t){const n=t.getFullYear(),o=r(t.getMonth()+1),i=r(t.getDate()),e=r(t.getHours()),u=r(t.getMinutes());return`${n}-${o}-${i} ${e}:${u}`}function r(t){return t<10?`0${t}`:String(t)}export{a,c as b};
