const a="ccc.buffer";async function o(){return new Promise(e=>{chrome.storage.local.get([a],t=>{const n=t[a]??[];e(n)})})}async function u(e,t){const n={id:s(),capturedAt:e.capturedAt,url:e.url,title:e.title,markdown:t},r=await o(),c=[n,...r];return await i(c),n}async function f(e){const n=(await o()).filter(r=>r.id!==e);await i(n)}async function d(){await i([])}async function p(){const e=await o();return e.length===0?"":[...e].reverse().map(n=>n.markdown).join(`

---

`)}async function i(e){return new Promise(t=>{chrome.storage.local.set({[a]:e},()=>t())})}function s(){return typeof crypto<"u"&&"randomUUID"in crypto?crypto.randomUUID():`id-${Date.now()}-${Math.random().toString(36).slice(2)}`}export{f as a,u as b,d as c,p as e,o as r};
